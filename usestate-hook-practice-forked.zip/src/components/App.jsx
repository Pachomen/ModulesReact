import React, { useState } from "react";

function App() {
  const [value, fun] = useState("TIME");

  function setTime() {
    let time = new Date().toLocaleTimeString();
    fun(time);
    setInterval(setTime, 1000);
  }

  return (
    <div className="container">
      <h1>{value}</h1>
      <button onClick={setTime}>Get Time</button>
    </div>
  );
}

export default App;
